function toggleMode() {
  document.body.classList.toggle("dark-mode");
}
